#
#<?php die('Forbidden.'); ?>
#Date: 2013-07-19 00:34:34 UTC
#Software: Joomla Platform 12.2.0 Stable [ Neil Armstrong ] 21-September-2012 00:00 GMT

#Fields: datetime	priority	category	message
2013-07-19T00:34:34+00:00	INFO	upload	references
2013-07-19T00:34:59+00:00	INFO	upload	references
