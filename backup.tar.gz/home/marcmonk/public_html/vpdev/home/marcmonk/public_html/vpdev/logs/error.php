#
#<?php die('Forbidden.'); ?>
#Date: 2014-08-23 16:44:20 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority	category	message
2014-08-23T16:44:20+00:00	INFO	cookiefailure	Username and password do not match or you do not have an account yet.
